# set JAVA_HOME to a valid JRE location
#JAVA_HOME=jre
echo JDbMonitor v1.1 - Client
echo Copyright 2006-2008 JDbMonitor. Visit our website at http://www.jdbmonitor.com/
echo "(Make sure JAVA_HOME points to a valid JRE/JDK)"
echo JAVA_HOME=$JAVA_HOME
$JAVA_HOME/bin/java -Xmx256M -jar client/jdbmonitor-client.jar

