README.txt
----------
JDbMonitor v1.1 (2008-12-02)


JDbMonitor is a tool to monitor & analyse database performance for any Java
application. There are two main components to this software:

- JDbMonitor Driver (com.jdbmonitor.MonitorDriver)
This component acts as a proxy JDBC driver that monitors database activities. It
is located in the driver directory of the installation path. Configuration of
the driver is done via the MonitorDriver.properties file.

- JDbMonitor Client
This is the GUI application used to perform real time database performance
monitoring. It provides various timing information such as total processing
time, execution time, data transfer time and number of records retrieved from
each SQL statement.

DONATIONWARE
------------
As of JDbMonitor v1.10, a valid license key no longer required to use the 
software.

JDbMonitor can be used in both non-commercial and commercial software without 
any limitations or expiry period.

If JDbMonitor brings value to optimizing your applications' JDBC performance, 
show your appreciation by getting your organization to donate in support of our 
work at http://www.jdbmonitor.com/.


System Requirements
-------------------
JRE 1.5 and above is REQUIRED to use JDbMonitor Client.

JDbMonitor Driver will work with JRE 1.4 and above. It has not been
tested with JRE 1.3 as we do not think there is a demand for it. Let us
know if you think otherwise.

This is a 100% Java based solution, so it should run on any operating
system (OS) platform. It has been tested on the following OS:
  - Microsoft Windows XP
  - Ubuntu
  - Red Hat Enterprise Server 3
  - Fedora Core 5
  - Suse Linux 9


Setting Up
----------
For installation and configuration instructions, refer to INSTALL.TXT and
"File > Help Contents" in JDbMonitor Client.


Contact Us
----------
Homepage:
    http://www.jdbmonitor.com/

Email:
    support@jdbmonitor.com - Software support


--------------------------------------------------------------------------------
Copyright 2006-2008 JDbMonitor. Visit our website at http://www.jdbmonitor.com/
