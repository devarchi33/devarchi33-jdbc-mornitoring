# Set JAVA_HOME to a valid JRE location
#JAVA_HOME=jre
echo JDbMonitor v1.1 - Demo Application
echo Copyright 2006-2008 JDbMonitor. Visit our website at http://www.jdbmonitor.com/
echo "(Make sure JAVA_HOME points to a valid JRE/JDK)"
echo JAVA_HOME=$JAVA_HOME
$JAVA_HOME/bin/java -cp "demo:driver/jdbmonitor-driver.jar:driver/jdbmonitor-common.jar:demo/commons-collections-3.2.1.jar:demo/commons-dbcp-1.2.2.jar:demo/commons-pool-1.4.jar:demo/hsqldb-1.8.0.7.jar" com.jdbmonitor.driver.demo.DemoApplication

